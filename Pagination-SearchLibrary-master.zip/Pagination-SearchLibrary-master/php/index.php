<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/./Mock_test_1/pagination1.0/library1.0.js"></script>
	<style>
	input{
	width:50%;
	height:5%;
	border:1px;
	border-radius:05px;
	padding:8px 15px 8px 15px;
	margin:10px 0px 15px 0px;
	box-shadow:1px 1px 2px 1px grey;
	
	</style>
</head>
<?php  
$connection = mysql_connect("loclhost","root","Mock_test_db");
$db = mysql_select_db($connection'mock_test_tbl');

if(isset($_POST['search']))
$email=$_POST['email']{
$query = "SELECT * FROM Mock_test_db WHERE Email='$email' ";
$query_run = mysql_query($connection,$query);
while($row = mysql_fetch_array($query_run))
}
?>

<body>
	<div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12" >
                    <div class="card">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 text-center">
                              <form action="index.php"name="myform" method="POST">
							  <input type="text" name="search" placeholder="Enter Email To Search"/></br>
							  <input type="submit" value="submit" />
							  </form>
							  
                            </div>
                            
                            
                        </div>
                    </div>
                </div>           
            
            </div>
			<div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12" >
                    <div class="card">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 text-center">
                            <table>
                                        <tr>
                                          <td><?php echo $row['Id'];?></td>
                                          <td><?php echo $row['Name'];?></td>
                                          <td><?php echo $row['Email'];?></td>
                                          <td><?php echo $row['Phone'];?></td>
                                          <td><?php echo $row['Gender'];?></td>
                                        </tr>
                                 </table>
							  
                            </div>
                            
                            
                        </div>
                    </div>
                </div>           
            
            </div>
        </div>
    </div>
    <script type="text/javascript" src="/./Mock_test_1/js/frontend.js"></script>
</body>
</html>
						 
												 